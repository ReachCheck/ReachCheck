import org.apache.http.FormattedHeader;
import org.apache.http.HttpException;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.RequestAddCookies;
import org.apache.http.config.ConnectionConfig;
import org.apache.http.config.MessageConstraints;
import org.apache.http.config.Registry;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.IOException;
import java.nio.charset.CodingErrorAction;

public class HttpClientExample {
    public static void main(String[] args) throws HttpException, IOException {
        RequestAddCookies s = new RequestAddCookies();
        s.process(null,null);
        HttpVersion h = new HttpVersion(1,1);
    }
}
